// netlify/functions/freeastro-wheel.js
exports.handler = async (event) => ({statusCode:200, body: JSON.stringify({msg:"Wheel function working"})});