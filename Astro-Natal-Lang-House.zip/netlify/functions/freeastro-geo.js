// netlify/functions/freeastro-geo.js
exports.handler = async (event) => ({statusCode:200, body: JSON.stringify({msg:"Geo function working"})});