// netlify/functions/freeastro-planets.js
exports.handler = async (event) => ({statusCode:200, body: JSON.stringify({msg:"Planets function working"})});